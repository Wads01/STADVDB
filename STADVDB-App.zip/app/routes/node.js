const express = require('express');
const router = express.Router();

const { queryDatabase,
    executeQuery,
    transactionRead,
    executeTransaction,
    checkApptidExists,
    deleteUser,
    lockAndReadUser} = require('../public/commons/javascript/queryDatabase.js');

let nodeURL;
let databaseName;

async function getUserData(apptid) {
    const queries = [`SELECT * FROM appointments WHERE apptid = '${apptid}' LIMIT 1`];
  
    try {
      const userData = await transactionRead(databaseName, queries);
      if (userData.length > 0) {
        const user = userData[0];
        return user;
      } else {
        throw new Error('User not found');
      }
    } catch (error) {
      throw error;
    }
}

async function getNode(nodeName, databaseName, sqlQuery) {
    try {
        const query = await queryDatabase(databaseName, sqlQuery)
        const isoQuery = "SELECT @@global.transaction_isolation AS transactionIsolation";
        const result = await executeQuery(databaseName, isoQuery);
        const isolation = result[0].transactionIsolation;

        return {
            layout: 'node',
            title: 'Node',
            node: nodeName,
            isolation: isolation,
            query: query
        };
    } catch (error) {
        console.error(`Error executing query for ${nodeName} node:`, error);
        throw error; 
    }
}

router.get('/central', async (req, res, next) => {
    try {
        nodeURL = 'central';
        databaseName = 'central'
        const data = await getNode('Central Node', databaseName, 'SELECT * FROM appointments LIMIT 20');
        res.render('node', data);
    } catch (error) {
        next(error);
    }
});

router.get('/luzon', async (req, res, next) => {
    try {
        nodeURL = 'luzon';
        databaseName = 'luzon'
        const data = await getNode('Luzon Node', databaseName, 'SELECT * FROM appointments LIMIT 20');
        res.render('node', data);
    } catch (error) {
        next(error);
    }
});

router.get('/vismin', async (req, res, next) => {
    try {
        nodeURL = 'vismin';
        databaseName = 'vismin'
        const data = await getNode('VisMin Node', databaseName, 'SELECT * FROM appointments LIMIT 20');
        res.render('node', data);
    } catch (error) {
        next(error);
    }
});

router.get('/:apptid', async (req, res, next) => {
    try{
        const apptid = req.query.query;

        if(!apptid){
            res.render('./partials/error', {
                layout: null,
                title: 'Error',
                nodeURL: nodeURL
            })
        }

        const exists = await checkApptidExists(databaseName, apptid);

        if (!exists) {
            return res.render('./partials/error', {
                layout: null,
                title: 'Appointment Not Found',
                nodeURL: nodeURL
            });
        }

        const result = await executeQuery(databaseName, "SELECT @@global.transaction_isolation AS transactionIsolation");
        const isolation = result[0].transactionIsolation;

        const user = await getUserData(apptid);
        
        res.render('user', {
            layout: 'user',
            title: 'User',
            apptid: apptid,
            isolation: isolation,
            user: user[0],
            nodeURL: nodeURL
        })

    } catch (error) {
        next(error);
    }
})

router.post('/config/:apptid', async (req, res, next) => {
    try {
        const apptid = req.params.apptid;
        const { hospitalname, city, province } = req.body;

        const updateQueries = [];

        if (hospitalname) {
            updateQueries.push(`UPDATE appointments SET hospitalname = '${hospitalname}' WHERE apptid = '${apptid}'`);
        }
        if (city) {
            updateQueries.push(`UPDATE appointments SET city = '${city}' WHERE apptid = '${apptid}'`);
        }
        if (province) {
            updateQueries.push(`UPDATE appointments SET province = '${province}' WHERE apptid = '${apptid}'`);
        }

        const user = await lockAndReadUser(databaseName, apptid);

        if (!user) {
            return res.render('./partials/locked', {
                layout: null,
                title: 'Locked',
                nodeURL: nodeURL
            });
        }

        if (databaseName == 'luzon') {
            await executeTransaction('luzon', updateQueries);
        } else if (databaseName == "vismin") {
            await executeTransaction('vismin', updateQueries);
        }

        await executeTransaction('central', updateQueries);

        if (await checkApptidExists('luzon', apptid)) {
            await executeTransaction('luzon', updateQueries);
        } else {
            await executeTransaction('vismin', updateQueries);
        }


        res.redirect(`/node/${nodeURL}`);

    } catch (error) {
        next(error);
    }
});

router.delete('/delete/:apptid', async (req, res, next) => {
    try{
        const apptid = req.params.apptid;

        const deleteQuery = `DELETE FROM appointments WHERE apptid = '${apptid}'`

        deleteUser(databaseName, deleteQuery, apptid)

        res.redirect(`/node/${nodeURL}`)
    } catch (error) {
        next(error);
    }
})

module.exports = router;
