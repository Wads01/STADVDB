const mysql = require('mysql');
const db = require('../../../db');

function createConnection(databaseConfig) {
  const connection = mysql.createConnection({
    host: databaseConfig.host,
    port: databaseConfig.port,
    user: databaseConfig.username,
    password: databaseConfig.password,
    database: databaseConfig.database
  });

  return connection;
}

function createPool(databaseName) {
  const databaseConfig = db.databases.find(db => db.database === databaseName);
  if (!databaseConfig) {
    throw new Error(`Database '${databaseName}' not found in configuration`);
  }

  const pool = mysql.createPool({
    connectionLimit: 5,
    host: databaseConfig.host,
    port: databaseConfig.port,
    user: databaseConfig.username,
    password: databaseConfig.password,
    database: databaseConfig.database
  });

  return pool;
}

function executeQueryWithTransaction(sqlQuery, connection) {
  return new Promise((resolve, reject) => {
    connection.query(sqlQuery, (err, results) => {
      if (err) {
        reject(err);
      } else {
        resolve(results);
      }
    });
  });
}

function transactionRead(databaseName, queries) {
  return new Promise((resolve, reject) => {
    const pool = createPool(databaseName);

    pool.getConnection((getConnectionErr, connection) => {
      if (getConnectionErr) {
        reject(getConnectionErr);
        return;
      }

      connection.beginTransaction(async (beginErr) => {
        if (beginErr) {
          connection.release();
          reject(beginErr);
          return;
        }

        try {
          const userData = [];
          for (const query of queries) {
            const results = await executeQueryWithTransaction(query, connection);
            userData.push(results);
          }

          await executeQuery(databaseName, "DO SLEEP(3)")

          connection.commit((commitErr) => {
            if (commitErr) {
              connection.rollback(() => {
                connection.release();
                reject(commitErr);
              });
            } else {
              connection.release();
              resolve(userData);
            }
          });
        } catch (transactionError) {
          connection.rollback(() => {
            connection.release();
            reject(transactionError);
          });
        }
      });
    });
  });
}


function executeTransaction(databaseName, queries) {
  return new Promise((resolve, reject) => {
    const pool = createPool(databaseName);

    pool.getConnection((getConnectionErr, connection) => {
      if (getConnectionErr) {
        reject(getConnectionErr);
        return;
      }

      connection.beginTransaction(async (beginErr) => {
        if (beginErr) {
          connection.release();
          reject(beginErr);
          return;
        }

        try {
          for (const query of queries) {
            await executeQueryWithTransaction(query, connection);
          }

          connection.commit((commitErr) => {
            if (commitErr) {
              connection.rollback(() => {
                connection.release();
                reject(commitErr);
              });
            } else {
              connection.release();
              resolve();
            }
          });
        } catch (transactionError) {
          connection.rollback(() => {
            connection.release();
            reject(transactionError);
          });
        }
      });
    });
  });
}

function queryDatabase(databaseName, sqlQuery) {
  const databaseConfig = db.databases.find(dbConfig => dbConfig.database === databaseName);

  if (!databaseConfig) {
    return Promise.reject(new Error(`Database '${databaseName}' not found in configuration`));
  }

  const connection = createConnection(databaseConfig);

  return new Promise((resolve, reject) => {
    connection.connect((err) => {
      if (err) {
        console.error(`Error connecting to ${databaseName} database:`, err);
        reject(err);
        return;
      }

      connection.query(sqlQuery, (error, results) => {
        connection.end();

        if (error) {
          console.error(`Error querying ${databaseName} database:`, error);
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
  });
}

function executeQuery(databaseName, sqlQuery) {
  const databaseConfig = db.databases.find(dbConfig => dbConfig.database === databaseName);

  if (!databaseConfig) {
    return Promise.reject(new Error(`Database '${databaseName}' not found in configuration`));
  }

  const connection = createConnection(databaseConfig);

  return new Promise((resolve, reject) => {
    connection.connect(err => {
      if (err) {
        reject(err);
        return;
      }

      connection.query(sqlQuery, (err, results) => {
        connection.end();

        if (err) {
          reject(err);
          return;
        }

        resolve(results);
      });
    });
  });
}

async function checkApptidExists(databaseName, apptid) {
  const databaseConfig = db.databases.find(db => db.database === databaseName);
  const connection = createConnection(databaseConfig);

  return new Promise((resolve, reject) => {
    connection.connect(err => {
      if (err) {
        console.error(`Error connecting to ${databaseName} database:`, err);
        reject(err);
        return;
      }

      const sqlQuery = 'SELECT * FROM appointments WHERE apptid = ?';

      connection.query(sqlQuery, [apptid], (error, results) => {
        connection.end();

        if (error) {
          console.error(`Error querying ${databaseName} database:`, error);
          reject(error);
        } else {
          const exists = results && results.length > 0;
          resolve(exists);
        }
      });
    });
  });
}

async function deleteUser(databaseName, sqlQuery, userID) {
  const databaseConfig = db.databases.find(db => db.database === databaseName);
  const connection = createConnection(databaseConfig);

  return new Promise((resolve, reject) => {
    connection.connect(err => {
      if (err) {
        console.error(`Error connecting to ${databaseName} database:`, err);
        reject(err);
        return;
      }

      connection.query(sqlQuery, [userID], (error, results) => {
        connection.end();

        if (error) {
          console.error(`Error deleting user from ${databaseName} database:`, error);
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
  });
}

async function lockAndReadUser(databaseName, apptid) {
  const pool = createPool(databaseName);
  const connection = await getConnectionFromPool(pool);

  try {
    await beginTransaction(connection);

    const lockQuery = `SELECT * FROM appointments WHERE apptid = '${apptid}' FOR UPDATE`;
    const user = await executeQueryWithTransaction(lockQuery, connection);

    await commitTransaction(connection);

    return user;
  } catch (error) {
    await rollbackTransaction(connection);
    throw error;
  } finally {
    await releaseConnection(pool, connection);
  }
}

async function getConnectionFromPool(pool) {
  return new Promise((resolve, reject) => {
    pool.getConnection((err, connection) => {
      if (err) {
        reject(err);
      } else {
        resolve(connection);
      }
    });
  });
}

async function beginTransaction(connection) {
  return new Promise((resolve, reject) => {
    connection.beginTransaction(err => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

async function commitTransaction(connection) {
  return new Promise((resolve, reject) => {
    connection.commit(err => {
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

async function rollbackTransaction(connection) {
  return new Promise((resolve, reject) => {
    connection.rollback(() => {
      resolve();
    });
  });
}

async function releaseConnection(pool, connection) {
  connection.release();
}

module.exports = {
  queryDatabase: queryDatabase,
  executeQuery: executeQuery,
  transactionRead: transactionRead,
  executeTransaction: executeTransaction,
  checkApptidExists: checkApptidExists,
  deleteUser: deleteUser,
  lockAndReadUser: lockAndReadUser
};