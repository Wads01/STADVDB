var env = require('dotenv').config()
module.exports = {

    databases : [
        {
            'database': process.env.RDS_DATABASE1,
            'username': process.env.RDS_USERNAME,
            'password': process.env.RDS_PASSWORD,
            'host': process.env.RDS_HOSTNAME,
            'port': process.env.RDS_PORT1
        },
        {
            'database': process.env.RDS_DATABASE2,
            'username': process.env.RDS_USERNAME,
            'password': process.env.RDS_PASSWORD,
            'host': process.env.RDS_HOSTNAME,
            'port': process.env.RDS_PORT2
        },
        {
            'database': process.env.RDS_DATABASE3,
            'username': process.env.RDS_USERNAME,
            'password': process.env.RDS_PASSWORD,
            'host': process.env.RDS_HOSTNAME,
            'port': process.env.RDS_PORT3
        }
    ]
}