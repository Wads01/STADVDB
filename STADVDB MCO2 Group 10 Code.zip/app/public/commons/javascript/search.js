$(document).ready(function() {
    $('#searchForm').submit(function(event){
        const apptid = $('#querying').val().trim();

        if (apptid) {
            window.location.href = `/node/appt/${apptid}`;
        } else {
            alert('Please enter an ApptId.');
        }
    });
});