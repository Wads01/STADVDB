const express = require('express');
const router = express.Router();

const { queryDatabase,
    executeQuery,
    transactionRead,
    executeTransaction,
    checkApptidExists,
    deleteUser,
    lockAndReadUser} = require('../public/commons/javascript/queryDatabase.js');

let nodeURL;
let databaseName;

const centralLog = [];
const luzonLog = [];
const visminLog = [];

async function recoverQueries(databaseName, logArray) {
    try {
        if (!Array.isArray(logArray)) {
            throw new Error('Invalid log array provided');
        }

        for (const updateQueries of logArray) {
            await executeTransaction(databaseName, updateQueries);
        }

        logArray.length = 0;
    } catch (error) {
        console.error(`Error executing queries from ${databaseName} log:`, error);
        throw error;
    }
}

async function getUserData(apptid) {
    const queries = [`SELECT * FROM appointments WHERE apptid = '${apptid}' LIMIT 1`];
  
    try {
      const userData = await transactionRead(databaseName, queries);
      if (userData.length > 0) {
        const user = userData[0];
        return user;
      } else {
        throw new Error('User not found');
      }
    } catch (error) {
      throw error;
    }
}

async function getNode(nodeName, databaseName, sqlQuery) {
    try {
        const query = await queryDatabase(databaseName, sqlQuery)
        const isoQuery = "SELECT @@global.transaction_isolation AS transactionIsolation";
        const result = await executeQuery(databaseName, isoQuery);
        const isolation = result[0].transactionIsolation;

        return {
            layout: 'node',
            title: 'Node',
            node: nodeName,
            isolation: isolation,
            query: query
        };
    } catch (error) {
        console.error(`Error executing query for ${nodeName} node:`, error);
        throw error; 
    }
}

router.get('/unavailable', async (req, res, next) =>{
    try{
        res.render('./partials/unavailable', {
            layout: null,
            title: 'Offline'
        })
        
    } catch (error) {
        next(error);
    }
})

router.get('/replicate-failure', async (req, res, next) =>{
    try{
        res.render('./partials/repfail', {
            layout: null,
            title: 'Offline',
            nodeURL: nodeURL
        })
        
    } catch (error) {
        next(error);
    }
})

router.get('/central', async (req, res, next) => {
    try {
        nodeURL = 'central';
        databaseName = 'central'
        const data = await getNode('Central Node', databaseName, 'SELECT * FROM appointments LIMIT 20');

        recoverQueries(databaseName, centralLog)

        res.render('node', data);
    } catch (error) {
        res.redirect('/node/unavailable');
        next(error);
    }
});

router.get('/luzon', async (req, res, next) => {
    try {
        nodeURL = 'luzon';
        databaseName = 'luzon'
        const data = await getNode('Luzon Node', databaseName, 'SELECT * FROM appointments LIMIT 20');

        recoverQueries(databaseName, luzonLog)

        res.render('node', data);
    } catch (error) {
        res.redirect('/node/unavailable');
        next(error);
    }
});

router.get('/vismin', async (req, res, next) => {
    try {
        nodeURL = 'vismin';
        databaseName = 'vismin'
        const data = await getNode('VisMin Node', databaseName, 'SELECT * FROM appointments LIMIT 20');

        recoverQueries(databaseName, visminLog)

        res.render('node', data);
    } catch (error) {
        res.redirect('/node/unavailable');
        next(error);
    }
});

router.get('/:apptid', async (req, res, next) => {
    try{
        const apptid = req.query.query;

        if(!apptid){
            res.render('./partials/error', {
                layout: null,
                title: 'Error',
                nodeURL: nodeURL
            })
        }

        const exists = await checkApptidExists(databaseName, apptid);

        if (!exists) {
            return res.render('./partials/error', {
                layout: null,
                title: 'Appointment Not Found',
                nodeURL: nodeURL
            });
        }

        const result = await executeQuery(databaseName, "SELECT @@global.transaction_isolation AS transactionIsolation");
        const isolation = result[0].transactionIsolation;

        const user = await getUserData(apptid);
        
        res.render('user', {
            layout: 'user',
            title: 'User',
            apptid: apptid,
            isolation: isolation,
            user: user[0],
            nodeURL: nodeURL
        })

    } catch (error) {
        next(error);
    }
})

router.post('/config/:apptid', async (req, res, next) => {
    try {
        const apptid = req.params.apptid;
        const { hospitalname, city, province } = req.body;

        const updateQueries = [];

        if (hospitalname) {
            updateQueries.push(`UPDATE appointments SET hospitalname = '${hospitalname}' WHERE apptid = '${apptid}'`);
        }
        if (city) {
            updateQueries.push(`UPDATE appointments SET city = '${city}' WHERE apptid = '${apptid}'`);
        }
        if (province) {
            updateQueries.push(`UPDATE appointments SET province = '${province}' WHERE apptid = '${apptid}'`);
        }

        const user = await lockAndReadUser(databaseName, apptid);

        if (!user) {
            return res.render('./partials/locked', {
                layout: null,
                title: 'Locked',
                nodeURL: nodeURL
            });
        }

        await executeTransaction(databaseName, updateQueries);

        if (databaseName == 'luzon') {
            try{
                await executeTransaction('central', updateQueries);
            } catch (error){
                centralLog.push(updateQueries);
                res.redirect(`/node/replicate-failure`)
            }
        }
        else if (databaseName == "vismin") {
            try{
                await executeTransaction('central', updateQueries);
            } catch (error){
                centralLog.push(updateQueries);
                res.redirect(`/node/replicate-failure`)
            }
        }
        else{
            try{
                if (await checkApptidExists('luzon', apptid)) {
                    try{
                        await executeTransaction('luzon', updateQueries);
                    } catch (error){
                        luzonLog.push(updateQueries);
                        res.redirect(`/node/replicate-failure`)
                    }
                }
                else {
                    try{
                        await executeTransaction('vismin', updateQueries);
                    } catch (error){
                        visminLog.push(updateQueries);
                        res.redirect(`/node/replicate-failure`)
                    }
                }
            } catch (error){
                luzonLog.push(updateQueries);
                res.redirect(`/node/replicate-failure`)
            }
        }

        res.redirect(`/node/${nodeURL}`);
    } catch (error) {
        next(error);
    }
});

router.delete('/delete/:apptid', async (req, res, next) => {
    try{
        const apptid = req.params.apptid;

        const deleteQuery = `DELETE FROM appointments WHERE apptid = '${apptid}'`

        deleteUser(databaseName, deleteQuery, apptid)

        res.redirect(`/node/${nodeURL}`)
    } catch (error) {
        next(error);
    }
})

module.exports = router;
